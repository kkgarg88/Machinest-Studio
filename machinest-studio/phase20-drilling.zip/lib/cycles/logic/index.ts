import 'server-only'
import { CycleResult } from './common'
import { millingG81 } from './milling-g81'
import { millingPeck } from './milling-peck'
import { millingEllipse } from './milling-ellipse'
import { buildPeckIntroSvg } from './peck-svg'
import { turningChamfer } from './turning-chamfer'
import { turningRadius } from './turning-radius'
import { turningOdGroove } from './turning-odgroove'
import { turningG71 } from './turning-g71'
import { turningG72 } from './turning-g72'
import { turningFaceGroove } from './turning-facegroove'
import { turningThread } from './turning-thread'
import { turningDrill } from './turning-drill'
import { millingEngrave } from './milling-engrave'
import { millingFaceMill } from './milling-facemill'
import { millingHelical } from './milling-helical'
import { millingTap } from './milling-tap'

type Logic = (v: Record<string, unknown>) => CycleResult
type Intro = () => string

const registry: Record<string, Logic> = {
  'milling-studio:G81': millingG81,
  'milling-studio:G83/G73': millingPeck,
  'milling-studio:ELLIPSE': millingEllipse,
  'turning-studio:CHAMFER': turningChamfer,
  'turning-studio:RADIUS': turningRadius,
  'turning-studio:OD-GROOVE': turningOdGroove,
  'turning-studio:G71': turningG71,
  'turning-studio:G72': turningG72,
  'turning-studio:FACE-GROOVE': turningFaceGroove,
  'turning-studio:THREAD-OD': turningThread,
  'turning-studio:G83': turningDrill,
  'milling-studio:ENGRAVE': millingEngrave,
  'milling-studio:CIRC-INTERP': millingHelical,
  'milling-studio:FACE-MILL': millingFaceMill,
  'milling-studio:TAP': millingTap,
}

// page khulte hi dikhne wala example / animation (optional, har cycle ke liye)
const intros: Record<string, Intro> = {
  'milling-studio:G83/G73': buildPeckIntroSvg,
}

export function getCycleLogic(key: string): Logic | undefined {
  return registry[key]
}

export function getCycleIntro(key: string): Intro | undefined {
  return intros[key]
}
